This is the source of CESANTA_FLASHER_STUB.
